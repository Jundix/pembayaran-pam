<div>
	<form action="<?php echo e(route('payment.create')); ?>" method="POST" id="formTagihan">
		<?php echo csrf_field(); ?>
		<div class="form-row">
				<div class="col-9 col-lg-10">
					<input class="form-control form-control-lg <?php $__errorArgs = ['nomor_meter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nomor_meter" id="nomorMeter" type="text" placeholder="ID Pelanggan" autocomplete="off" autofocus wire:model.debounce.400ms="nomor_meter">
					<?php $__errorArgs = ['nomor_meter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="col-3 col-lg-2 col-btn">
				<button class="btn btn-lg w-100 btn-secondary-custom" type="submit" id="btnPay" <?php echo e($usages ? '' : 'disabled'); ?>>
						<span class="spinner-border spinner-border-sm mb-1" wire:loading wire:target="nomor_meter"></span>
						Bayar
				</button>
			</div>
			<div class="col-12 col-alert-info">
				<div class="alert alert-info alert-dismissible fade show mt-3 mb-0">
					<button type="button" class="close" data-dismiss="alert">
					<span>&times;</span>
					</button>
					<h5 class="alert-heading">Keterangan</h5>
					<p class="mb-0">
						<ol>
								<li>
								Transaksi Tagihan Air yang dilakukan pukul 23:30-00.59 WIB akan mulai diproses pada pukul 01.00 WIB sesuai kebijakan.
								</li>
								<li>Jatuh tempo pembayaran tagihan Air adalah <strong>tanggal 20 di setiap bulannya</strong>.</li>
								<li>Proses verifikasi pembayaran maksimum <strong>2x24 jam hari kerja</strong>.</li>
						</ol>
					</p>
				</div>
			</div>
		</div>
	</form>
	<?php if(!empty($usages) && !empty($plnCustomer)): ?>
		<div class="table-responsive">
			<table class="table text-center table-bordered table-stripped table-hover mt-3" id="billTable">
				<thead>
					<tr>
						<th scope="col">Nama Lengkap</th>
						<th scope="col">Jumlah Periode</th>
						<th scope="col">Periode</th>
						<th scope="col">Biaya Admin</th>
						<th scope="col">Total Denda</th>
						<th scope="col">Tagihan</th>
						<th scope="col">Total Tagihan</th>
					</tr>
				</thead>
				<tbody>
						<tr scope="row">
							<td><?php echo e($plnCustomer->nama_pelanggan); ?></td>
							<td><?php echo e($usages->count()); ?></td>
							<td>
								<?php if($usages->count() > 1): ?>
									<?php echo e(optional($usages->first())->month_name . '-' . optional($usages->last())->month_name. ' ' . optional($usages->first())->tahun); ?>

								<?php else: ?>
									<?php echo e(optional($usages->first())->month_name . ' ' . optional($usages->first())->tahun); ?>

								<?php endif; ?>
							</td>
							<td>Rp. <?php echo number_format(config('const.biaya_admin'), 2, ',', '.'); ?></td>
							<td>Rp. <?php echo number_format(collect($data)->sum('denda'), 2, ',', '.'); ?></td>
							<td>Rp. <?php echo number_format(collect($data)->sum('total_tagihan'), 2, ',', '.'); ?></td>
							<td class="font-weight-bold">Rp. <?php echo number_format($total, 2, ',', '.'); ?></td>
						</tr>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>
<script type="text/javascript">
      // For example trigger on button clicked, or any time you need
      var payButton = document.getElementById('btnPay');
      payButton.addEventListener('click', function () {
        // Trigger snap popup. @TODO: Replace TRANSACTION_TOKEN_HERE with your transaction token
        window.snap.pay('');
        // customer will be redirected after completing payment pop-up
      });
    </script>

<?php $__env->startPush('addon-script'); ?>
	<script >
		Livewire.on('alertAlreadyPayBill', () => {
				Swal.fire({
					'title': 'Tagihan Sudah Terbayar',
					'icon': 'success',
					'showConfirmButton': true
				})
		});
	</script>
	 
<?php $__env->stopPush(); ?>
<?php /**PATH /home/jundix/Downloads/yogi/resources/views/livewire/check-bill.blade.php ENDPATH**/ ?>