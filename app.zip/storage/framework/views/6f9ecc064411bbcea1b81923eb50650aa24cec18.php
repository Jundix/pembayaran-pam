<?php echo e($slot); ?>

<?php /**PATH /home/jundix/Downloads/yogi/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>