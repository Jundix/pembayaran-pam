<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan Pembayaran</title>
  <link rel="stylesheet" href="<?php echo e(public_path('css/app.css')); ?>">
  <style>
    .page-break {
        page-break-after: always;
    }
    .title{
      margin-top: -100px;
    }
  </style>
</head>
<body class="bg-white">
  <nav class="navbar navbar-light">
    <span class="navbar-brand">
      
    </span>
    <ul class="navbar-nav text-center"><br>
      <li class="nav-item">
        <br>
        <br>
        Dukuh Ringin <br>
        Telp :
      </li>
    </ul>
  </nav>
  <h1 class="text-center mb-3 title">Laporan Pembayaran PAMSIMAS</h1><br>
  <p class="mb-0">
    <?php if($request->action == 'print_per_date'): ?>
      Periode : <?php echo e($request->print_per_date['tanggal_awal'] . ' sampai ' . $request->print_per_date['tanggal_akhir']); ?>

    <?php elseif($request->action == 'today_report'): ?>
      Periode : <?php echo e(now()->format('d-m-Y')); ?>

    <?php elseif($request->action == 'this_month_report'): ?>
      Periode : <?php echo e(now()->locale('id')->monthName . ' ' . now()->year); ?>

    <?php elseif($request->action == 'last_month_report'): ?>
      Periode : <?php echo e(now()->subMonth()->locale('id')->monthName . ' ' . now()->year); ?>

    <?php endif; ?>
  </p>
  <table class="w-100 mb-3">
    <tr>
      <td>Dibuat Pada : <?php echo e(now()->format('d-m-Y')); ?></td>
      <td class="text-right">Total Transaksi : <?php echo e($payments->count()); ?></td>
    </tr>
  </table>

  <table class="table table-bordered table-striped text-center">
    <thead>
      <tr>
        <th>No.</th>
        <th>Nama Pelanggan</th>
        <th>Tanggal Bayar</th>
        <th>Total Bayar</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($payment->nama); ?></td>
          <td><?php echo e($payment->tanggal); ?>, <?php echo e($payment->bulan); ?> <?php echo e($payment->tahun); ?></td>
          <td>Rp.<?php echo e($payment->jumlah_bayar); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH /home/jundix/Downloads/yogi_new/pamsimas/resources/views/pages/admin/report-payments.blade.php ENDPATH**/ ?>