<footer class="border-top border-bottom py-3 py-md-0">
  <div class="container d-flex justify-content-center align-items-center">
    <div class="row">
      <div class="col-12 col-md-auto help-link">
        <!-- <img src="<?php echo e(asset('assets/img/megamendung-logo.png')); ?>" width="120" height="63" alt="Logo Mega Mendung"> -->
        <h3>PAMSIMAS Pemerintah Desa Dukuhwringin</h3>
      </div>
    </div>
  </div>
  <div class="copyright d-flex justify-content-center align-items-center p-3">
    <span>© <?php echo e(date('Y')); ?> PAMSIMAS</span>
  </div>
</footer><?php /**PATH /home/jundix/Downloads/yogi/resources/views/includes/footer.blade.php ENDPATH**/ ?>