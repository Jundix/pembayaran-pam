<!-- Bootstrap JS -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<!-- DataTables v.1.10.23 + Responsive v.2.2.7 + Button v.1.6.5 (BS v.4.1 Integration)-->
<script src="<?php echo e(asset('assets/plugin/DataTables-1.10.24/datatables.min.js')); ?>"></script>
<?php /**PATH /home/jundix/Downloads/yogi/resources/views/includes/script.blade.php ENDPATH**/ ?>