<?php $__env->startSection('title', 'Edit Penggunaan'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <h3 class="mb-4">Edit Penggunaan</h3>
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('update_penggunaan')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <?php $__currentLoopData = $usage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <input type="hidden" name="id" value="<?php echo e($usage->id); ?>">
          <div class="form-group">
            <label for="selectPlnCustomer">Nama Pelanggan <span class="text-danger">*</span></label>
            <select 
                    name="id_pelanggan" 
                    class="form-control selectpicker <?php $__errorArgs = ['id_pelanggan_pln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-live-search="true" 
                    id="selectPlnCustomer"
            >
              <option selected>Pilih Pelanggan</option>
              <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pelanggan->id); ?>" <?php echo e(($pelanggan->id == $usage->id_pelanggan) ? 'selected' : ''); ?>>
                  <?php echo e($pelanggan->id . '. ' . $pelanggan->nama_pelanggan); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_pelanggan_pln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label for="inputMeterAwal">Meter Awal <span class="text-danger">*</span></label>
            <input 
                  type="text" 
                  name="meter_awal" 
                  class="form-control <?php $__errorArgs = ['meter_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                  id="inputMeterAwal" 
                  value="<?php echo e(old('meter_awal', $usage->meter_awal)); ?>" 
                  placeholder="Masukkan meter awal"
            >

            <?php $__errorArgs = ['meter_awal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label for="inputMeterAkhir">Meter Akhir <span class="text-danger">*</span></label>
            <input 
                  type="text" 
                  name="meter_akhir" 
                  class="form-control <?php $__errorArgs = ['meter_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                  id="inputMeterAkhir" 
                  value="<?php echo e(old('meter_akhir', $usage->meter_akhir)); ?>" 
                  placeholder="Masukkan meter akhir">

            <?php $__errorArgs = ['meter_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
          <div class="form-group">
            <label for="selectBulan">Bulan <span class="text-danger">*</span></label>
            <select name="bulan" class="form-control selectpicker <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="selectBulan" data-live-search="true">
              <option disabled>Pilih Bulan</option>
              <?php $__currentLoopData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($month); ?>" <?php echo e($month === old('month') || $month === $usage->bulan ? 'selected' : ''); ?>>
                    <?php echo e(\Carbon\Carbon::create(0, $month)->monthName); ?>

                  </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="form-group">
            <label for="inputTahun">Tahun <span class="text-danger">*</span></label>
            <input type="text" name="tahun" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputTahun" value="<?php echo e(old('tahun', $usage->tahun)); ?>">
            
            <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route('admin')); ?>" class="btn btn-danger mr-1">Batal</a>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
<!-- Datepicker Bahasa Indonesia -->
<script src="<?php echo e(asset('assets/plugin/bootstrap-datepicker/locales/bootstrap-datepicker.id.min.js')); ?>"></script>
<script>
  $('#inputTahun').datepicker({
    language: "id",
    format: "yyyy",
    startView: 2,
    minViewMode: 2,
    maxViewMode: 2
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/yogi_new/pamsimas/resources/views/pages/admin/usage/edit.blade.php ENDPATH**/ ?>