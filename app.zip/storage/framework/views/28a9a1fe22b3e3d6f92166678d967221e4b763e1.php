<!-- Bootstrap CSS -->
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/fonts/bi-icons-1.3.0/font/bootstrap-icons.css')); ?>" rel="stylesheet" type="text/css">
<!-- DataTables v.1.10.23 + Responsive v.2.2.7 + Button v.1.6.5 (Bootstrap 4.1 Integration) -->
<link href="<?php echo e(asset('assets/plugin/DataTables-1.10.24/datatables.min.css')); ?>" rel="stylesheet"><?php /**PATH /home/jundix/Downloads/yogi/resources/views/includes/style.blade.php ENDPATH**/ ?>