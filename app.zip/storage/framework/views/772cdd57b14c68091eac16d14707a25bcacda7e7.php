<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white m-0 navbar-auth">
    <a class="navbar-brand mx-auto" href="">
      <!-- <img src="<?php echo e(asset('assets/img/megamendung-logo.png')); ?>" width="120" height="63.6" class="d-inline-block align-top" alt=""> -->
    <h1>PAMSIMAS</h1>
    </a>
</nav>
<!-- End of Navbar --><?php /**PATH /home/jundix/Downloads/yogi/resources/views/includes/navbar-alternate.blade.php ENDPATH**/ ?>