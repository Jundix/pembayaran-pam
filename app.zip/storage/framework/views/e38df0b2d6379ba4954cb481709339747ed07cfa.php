<?php $__env->startSection('title', 'Edit Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <h3 class="mb-4">Edit Pelanggan</h3>
    <div class="card">
      <div class="card-body">
      <form action="<?php echo e(route('admin.pln-customers.update', $plnCustomer->id)); ?> " method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputNama">Nama Pelanggan</label>
            <input type="text" name="nama_pelanggan" class="form-control" id="inputNama" placeholder="Masukkan nama" value="<?php echo e($plnCustomer->nama_pelanggan); ?>">
          </div>
          <div class="form-group col-md-6">
            <label for="inputNoMeter">No. Meter / ID Pelanggan</label>
            <input type="text" name="nomor_meter" class="form-control <?php $__errorArgs = ['nomor_meter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNoMeter" placeholder="Contoh: 537320018426" value="<?php echo e($plnCustomer->nomor_meter); ?>">
            
            <?php $__errorArgs = ['nomor_meter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback"><?php echo e($message); ?></span>   
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-group">
          <label for="inputAlamat">Alamat</label>
          <textarea name="alamat" class="form-control" id="inputAlamat" placeholder="Masukkan alamat"><?php echo e($plnCustomer->alamat); ?></textarea>
        </div>
        <div class="form-group">
          <label for="selectKota">Kota</label>
          <select name="id_kota" class="form-control selectpicker <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="selectKota" data-live-search="true">
            <option selected disabled>Pilih Kota</option>
            <?php $__currentLoopData = \Indonesia::allProvinces(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <optgroup label="<?php echo e($province->name); ?>">
              <?php $__currentLoopData = $province->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city->id); ?>" <?php echo e($city->id == $plnCustomer->id_kota ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>    
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
          <label for="selectGolonganTarif">Golongan Tarif</label>
          <select name="tariff_id" class="form-control" id="selectGolonganTarif">
            <option selected>Pilih Golongan Tarif</option>
            <?php $__currentLoopData = $tariffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tariff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($tariff->id); ?>" <?php echo e($tariff->id == $plnCustomer->id_tarif ? 'selected' : ''); ?>><?php echo e($tariff->golongan_tarif); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <a href="<?php echo e(route('admin.pln-customers.index')); ?>" class="btn btn-danger">Batal</a>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/yogi/resources/views/pages/admin/pln-customer/edit.blade.php ENDPATH**/ ?>