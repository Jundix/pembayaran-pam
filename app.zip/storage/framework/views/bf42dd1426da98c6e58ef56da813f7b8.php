<!-- Bootstrap v4.6 -->
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/fonts/bi-icons-1.3.0/font/bootstrap-icons.css')); ?>">

<!-- Custom Style -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

<!-- DataTables v.1.10.23 + Responsive v.2.2.7 + Button v.1.6.5 (Bootstrap 4.1 Integration) -->
<link href="<?php echo e(asset('assets/plugin/DataTables-1.10.24/datatables.min.css')); ?>" rel="stylesheet">

<!-- Bootstrap 4 Datepicker -->
<link href="<?php echo e(asset('assets/plugin/bootstrap-datepicker/css/bootstrap-datepicker.css')); ?>" rel="stylesheet">

<!-- Bootstrap 4 Select Plugin-->
<link href="<?php echo e(asset('assets/plugin/bootstrap-select-1.13.14/css/bootstrap-select.min.css')); ?>" rel="stylesheet"><?php /**PATH /home/jundix/Downloads/yogi_new/pamsimas/resources/views/includes/admin/style.blade.php ENDPATH**/ ?>