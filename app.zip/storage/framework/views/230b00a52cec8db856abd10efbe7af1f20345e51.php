<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($editGate)): ?>
  <a href="<?php echo e(route('admin.' . $crudRoutePart . '.edit', $row->id)); ?>" class="btn btn-success btn-sm btn-edit" data-id="<?php echo e($row->id); ?>">edit</a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($showGate)): ?>
  <a href="<?php echo e(route('admin.' . $crudRoutePart . '.show', $row->id)); ?>" class="btn btn-primary btn-sm btn-detail">detail</a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($deleteGate)): ?>
  <?php if(
       $row->id_level !== 1 && $row->getTable() === 'users' || 
       $row->getTable() === 'levels' && $row->id !== 1      || 
       !in_array($row->getTable(), ['users', 'levels'])
      ): ?>
    <form action="<?php echo e(route('admin.'. $crudRoutePart .'.destroy', $row->id)); ?>" method="POST" class="d-inline-block form-delete">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-danger btn-sm btn-delete">delete</button>
    </form>
  <?php endif; ?>
<?php endif; ?>

<?php /**PATH /home/jundix/Downloads/yogi/resources/views/partials/datatables-action.blade.php ENDPATH**/ ?>