<?php $__env->startSection('title', 'Tagihan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mb-3">
  <div class="alert alert-info alert-dismissible fade show" role="alert">
    <strong>Fitur Tagihan Air:</strong>
    <ol>
      <li>Data tagihan <strong>otomatis dibuat</strong> apabila Admin sudah memasukkan data penggunaan</li>
      <li>Status tagihan otomatis berubah menjadi <strong>LUNAS</strong> apabila pembayaran sukses</li>
    </ol>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <h3 class="mb-4">Tagihan Air</h3>
  <div class="card">
    <div class="card-body table-responsive">
    <table class="table table-striped table-bordered w-100" id="example">
            <th>ID</th>
            <th>Nama</th>
            <th>Bulan</th>
            <th>Penggunaan</th>
            <th>Jumlah yang Dibayarkan</th>
            <th>Status</th>
          
        <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->nama_pelanggan); ?></td>
        <td><?php echo e($item->bulan); ?> <?php echo e($item->tahun); ?></td>
        <td><?php echo e($item->jumlah_penggunaan); ?></td>
        <td><?php echo e($item->jumlah_bayar); ?></td>
        <td>
          <?php if($item->status == 0): ?>
          Belum Dibayarkan
          <?php else: ?>
          Lunas
          <?php endif; ?>
        </td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/yogi_new/pamsimas/resources/views/pages/admin/bill/index.blade.php ENDPATH**/ ?>