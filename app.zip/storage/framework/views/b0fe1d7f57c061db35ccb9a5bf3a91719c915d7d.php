<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-4">Pembayaran</h3>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">ID Pelanggan</th>
                        <th scope="col">Bulan</th>
                        <th scope="col">Tagihan</th>
                        <th scope="col">Pemeliharaan</th>
                        <th scope="col">Total Bayar</th>
                        <th scope="col">Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($index +1); ?></td>
                        <td><?php echo e($p->id_pelanggan); ?></td>
                        <td><?php echo e($p->bulan); ?></td>
                        <td>Rp. <?php echo e($p->tagihan); ?></td>
                        <td>Rp. <?php echo e($p->pemeliharaan); ?></td>
                        <td>Rp. <?php echo e($p->total_bayar); ?></td>
                        <td>
                            <form action="/pembayaran/continue" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="id_pelanggan" class="form-control <?php $__errorArgs = ['nama_pelanggan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->id_pelanggan); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="id_order" class="form-control <?php $__errorArgs = ['id_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->id); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="nama" class="form-control <?php $__errorArgs = ['nama_pelanggan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->nama_pelanggan); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="total_bayar" class="form-control <?php $__errorArgs = ['total_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->total_bayar); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="total_bayar" class="form-control <?php $__errorArgs = ['total_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->total_bayar); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="bulan" class="form-control <?php $__errorArgs = ['total_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->bulan); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <div class="form-row" hidden>
                                    <div class="form-group col-md-6">
                                        <input type="text" name="id_pelanggan" class="form-control <?php $__errorArgs = ['total_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inputNama" value="<?php echo e($p->id_pelanggan); ?>" placeholder="Masukkan nama">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success btn-sm">Lanjutkan pembayaran</button>
                            </form>
                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/yogi/resources/views/pages/pelanggan/pembayaran.blade.php ENDPATH**/ ?>