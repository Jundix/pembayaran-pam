<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('addon-style'); ?>
<script src="<?php echo e(asset('assets/plugin/Chart.js-3.0.2/chart.min.js')); ?>" charset="utf-8"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row justify-content-center">
      <!-- Total Revenue Overview -->
      <?php if(auth()->user()->isAdmin()): ?>
        <div class="col-12 col-md-6 col-lg-3 mb-3">
          <div class="card card-overview">
            <div class="card-body">
              <div class="row align-items-center h-100">
                <div class="col-4">
                  <img src="<?php echo e(asset('assets/img/mm-icon/revenue-icon@2x.png')); ?>" alt="Payment Icon" width="65" height="65">
                </div>
                <div class="col-8">
                  <h6 class="font-weight-bold"><?php echo e($totalPendapatan); ?></h6>
                  
                  Total Pendapatan
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <!-- End of Total Revenue Overview -->

      <!-- Total Payment Overview -->
      <?php if(auth()->user()->isAdmin()): ?>
        <div class="col-12 col-md-6 col-lg-3 mb-3">
          <div class="card card-overview">
            <div class="card-body">
              <div class="row align-items-center h-100">
                <div class="col-4">
                  <img src="<?php echo e(asset('assets/img/mm-icon/payment-icon@2x.png')); ?>" alt="Payment Icon" width="65" height="65">
                </div>
                <div class="col-8">
                  <h6 class="font-weight-bold"><?php echo e($payments->count()); ?></h6>
                  Total pembayaran
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php else: ?>
        <div class="col-12 col-md-6 col-lg-4 mb-3">
          <div class="card card-overview">
            <div class="card-body">
              <div class="row align-items-center h-100">
                <div class="col-4">
                  <img src="<?php echo e(asset('assets/img/mm-icon/payment-icon@2x.png')); ?>" alt="Payment Icon" width="65" height="65">
                </div>
                <div class="col-8">
                  <h6 class="font-weight-bold"><?php echo e($payments->count()); ?></h6>
                  <div>Total pembayaran</div>
                  <a href="<?php echo e(route('admin.payments.index')); ?>" class="text-decoration-none">Lihat detail pembayaran</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <!-- End of Total Payment Overview -->

      <!-- Bill Paid Off Overview -->
      <?php if(auth()->user()->isAdmin()): ?>
        <div class="col-12 col-md-6 col-lg-3 mb-3">
          <div class="card card-overview">
            <div class="card-body">
              <div class="row align-items-center h-100">
                <div class="col-4">
                  <img src="<?php echo e(asset('assets/img/mm-icon/bill-paid-off-icon@2x.png')); ?>" alt="Payment Icon" width="65" height="65">
                </div>
                <div class="col-8">
                  <h6 class="font-weight-bold"><?php echo e($bills->where('status', 'LUNAS')->count()); ?></h6>
                  Tagihan Air lunas
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <!-- End of Bill Paid Off Overview -->

      <!-- Bill Not Paid Off Overview -->
      <?php if(auth()->user()->isAdmin()): ?>
        <div class="col-12 col-md-6 col-lg-3 mb-3">
          <div class="card card-overview">
            <div class="card-body">
              <div class="row align-items-center h-100">
                <div class="col-4">
                  <img src="<?php echo e(asset('assets/img/mm-icon/bill-not-paid-off-icon@2x.png')); ?>" alt="Payment Icon" width="65" height="65">
                </div>
                <div class="col-8">
                  <h6 class="font-weight-bold"><?php echo e($bills->where('status', 'BELUM LUNAS')->count()); ?></h6>
                  Tagihan Air belum lunas
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endif; ?>

      
      <?php if(auth()->user()->isAdmin()): ?>
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <?php echo $chart->container(); ?>

            </div>
          </div>
        </div>
      <?php endif; ?>
      <!-- End of Bill Not Paid Off Overview -->
      <div class="col-12">
        <h2 class="text-center mt-5">Histori Pembayaran</h2>
        <div class="card my-5 ">
          <div class="card-body table-responsive">
            <table class="table table-striped table-bordered w-100" id="paymentHistories">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nama Customer</th>
                  <th>Nama Pelanggan </th>
                  <th>ID Tagihan</th>
                  <th>Tanggal Bayar</th>
                  <th>Biaya Admin</th>
                  <th>Denda</th>
                  <th>Total Bayar</th>
                  <th>Metode Pembayaran</th>
                  <th>Status</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-script'); ?>
  <?php echo $chart->script(); ?>

  <script>
    console.log(window);
    $('#paymentHistories').DataTable({
        responsive: true,
        serverSide: true,
        ajax: "",
        columns: [
            {data: 'id'},
            {data: 'nama'},
            {data: 'nama_pelanggan'},
            {data: 'id_tagihan'},
            {data: 'tanggal_bayar'},
            {data: 'biaya_admin',
             render: $.fn.dataTable.render.number('.', ',', 2, 'Rp ')
            },
            {data: 'denda',
             render: $.fn.dataTable.render.number('.', ',', 2, 'Rp ')
            },
            {data: 'total_bayar',
             render: $.fn.dataTable.render.number('.', ',', 2, 'Rp ')
            },
            {data: 'payment.payment_method.nama', defaultContent: '-'},
            {data: 'status',
              render: function(data, type, row){
                let state;
                if(data == 'success'){
                  state = 'success';
                }else if(data == 'pending'){
                  state = 'warning';
                }else{
                  state = 'danger';
                }
                return `<span class='badge badge-pill 
                        badge-${state}'>${data}</span>`;
              }
            },
        ]
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/yogi/resources/views/pages/admin/index.blade.php ENDPATH**/ ?>