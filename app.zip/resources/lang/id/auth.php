<?php

return [
  'failed' => 'Kredensial ini tidak cocok dengan catatan kami.',
  'password' => 'Password yang diberikan salah.',
  'throttle' => 'Terlalu banyak percobaan login. Silakan tunggu lagi dalam :seconds detik.'
];