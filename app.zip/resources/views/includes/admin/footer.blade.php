<footer class="admin-footer bg-white border-top w-100 mt-auto">
  <div class="container d-flex justify-content-center align-items-center">
    <div class="copyright">
      © {{date('Y')}} PAMSIMAS
    </div>
  </div>
</footer>