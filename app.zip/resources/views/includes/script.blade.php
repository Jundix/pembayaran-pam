<!-- Bootstrap JS -->
<!-- DataTables v.1.10.23 + Responsive v.2.2.7 + Button v.1.6.5 (BS v.4.1 Integration)-->
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
<script>(document).ready( function () {
    $('#example').DataTable();
} );</script>
