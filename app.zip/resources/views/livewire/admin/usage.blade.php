<div class="card">
    <div class="card-body">
      <table class="table table-striped table-bordered w-100" id="usages">
        <thead>
          <tr>
            <th>
              <input type="checkbox" wire:model="selectAll">
            </th>
            <th>ID</th>
            <th>Nama Pelanggan</th>
            <th>Bulan</th>
            <th>Tahun</th>
            <th>Meter Awal</th>
            <th>Meter Akhir</th>
            <th>Action</th>
          </tr>
        </thead>
      </table>
    </div>
</div>