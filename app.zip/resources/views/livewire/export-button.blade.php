<div>
    <button class="btn btn-primary" wire:click="exportReceiptOfPayment"><i class="bi bi-download"></i> {{ $text }}</button>
</div>
