@extends('layouts.app')

@section('title', 'About Us')

@section('content')
  <div class="container pt-5">
    <h1 class="text-center font-weight-bold">Tentang Kami</h1>
    <p class="text-center lead">
      Aplikasi ini adalah sebuah platform pembayaran air yang berbasis progressive website apps <br>
      dimana warga desa Dukuhwringin dapat mengecek info tagihan Pamsimas dan membayar pamsimas secara mudah dan efisien.
    </p>
  </div>
@endsection